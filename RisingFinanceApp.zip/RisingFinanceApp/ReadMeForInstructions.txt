--------------------------------------------------------------

Sehr geehrter Herr Jung, CEO der Jung Bank AG!

Sie haben sich also dazu entschieden, die App auszuprobieren.
Dazu müssen Sie allerdings ein paar Vorkehrungen treffen.:

1. Zuerst laden Sie sich die App auf Ihr ANDROID Smartphone.
   Diese APK funktioniert ausschließlich auf Android.

2. Suchen Sie in Ihrem Dateimanager nach der App

3. Da dies keine APK aus dem Play Store ist, werden Sie dazu
   aufgefordert, in den Einstellungen der Quelle zu vertrauen.
   Danach sollte sich die App installieren.

Viel Spaß beim ausprobieren der App!

Ihr Rising Finance Team

--------------------------------------------------------------

